import React from 'react';
import Model from '../Model.js';






export default class HomeModel extends Model{

constructor(props){

super(props);

this.state={
...this.state
};

}





render(){
//return super.render();
}




}
