import React from 'react';






export default class Model extends React.Component{

constructor(props){

super(props);

this.state={
...this.state
};

this.page=props.page;
this.controller=props.controller;
this.c=props.args;
this.args=props.args;

}





render(){
}




}
