import React from 'react';
import View from '../View';






export default class HomeView extends View{

constructor(props){
super(props);
this.state={
...this.state,
};
}








default(){
return (
<h1>i am view default</h1>
);
}










render(){
return super.render();
}


}
