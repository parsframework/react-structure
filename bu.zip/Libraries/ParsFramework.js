import * as Os from './Os/__init__.js';








export const ParsFramework={
Os,
};

export default ParsFramework;

