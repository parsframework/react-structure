<?php
namespace ParsFramework\Configs;
use ParsFramework\Includes as I;
use ParsFramework\Models as M;





if(!class_exists('Config')){
class Config{





function __construct(){

$model=new M\Model();

}





}}

