import React from 'react'
import ReactDOM from 'react-dom/client'
import Urls from './Urls'







ReactDOM.createRoot(document.getElementById('root')).render(
<React.StrictMode>
<Urls />
</React.StrictMode>
)


